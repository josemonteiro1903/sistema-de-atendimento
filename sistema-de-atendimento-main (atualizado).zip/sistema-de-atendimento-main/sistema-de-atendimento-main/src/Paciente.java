public class Paciente {

    //atributos solicitados da classe paciente
    private int idPaciente;
    private String nome;
    private int idade;
    private int cpf;
    private String prioridade;
    private String sintomas;
    private String statusAtendimento;

    //construtor da classe paciente
    public Paciente(int idPaciente, String nome, int idade, int cpf, String prioridade, String sintomas, String statusAtendimento) {
        this.idPaciente = idPaciente;
        this.nome = nome;
        this.idade = idade;
        this.cpf = cpf;
        this.prioridade = prioridade;
        this.sintomas = sintomas;
        this.statusAtendimento = statusAtendimento;
    }

    
    public void cadastrar(){
        System.out.println("Paciente "+this.nome+" Cadastrado com sucesso");
        
    }
    
    public void exibirStatus(){
        System.out.println(toString());
    }
    
    
    public void atualizarStatus(String novosSintomas, String novoStatus){
        this.sintomas = novosSintomas;
        this.statusAtendimento = novoStatus;
        System.out.println("Dados de "+ this.nome+ "Atualizados" );
    }

    @Override
    public String toString() {
        return "Paciente [idPaciente=" + idPaciente + ", nome=" + nome + ", idade=" + idade + ", cpf=" + cpf
                + ", prioridade=" + prioridade + ", sintomas=" + sintomas + ", statusAtendimento=" + statusAtendimento
                + "]";
    }


    public String getSintomas() {
        return sintomas;
    }

}
